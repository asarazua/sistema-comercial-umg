package com.umg.comercial.ui;

import com.umg.comercial.db.ConexionOracle;
import com.umg.comercial.grafo.Grafo;
import com.umg.comercial.grafo.NodoGrafo;
import com.umg.comercial.grafo.AristaGrafo;
import com.umg.comercial.hash.NodoHash;
import com.umg.comercial.hash.TablaHash;
import com.umg.comercial.modelo.*;
import com.umg.comercial.reporte.GeneradorReporte;

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.sql.*;
import java.util.*;
import java.util.List;

/**
 * Ventana principal del Sistema de Gestión Comercial UMG.
 * Interfaz gráfica Swing con pestañas para Hash, Grafo, Facturas y Reportes.
 */
public class VentanaPrincipal extends JFrame {

    // Colores corporativos
    static final Color AZUL_UMG    = new Color(0, 51, 102);
    static final Color AZUL_CLARO  = new Color(0, 102, 204);
    static final Color VERDE       = new Color(0, 153, 76);
    static final Color NARANJA     = new Color(204, 102, 0);
    static final Color GRIS_FONDO  = new Color(245, 245, 250);
    static final Color BLANCO      = Color.WHITE;

    // Estructuras de datos
    TablaHash<Integer, Producto>    hashProductos   = new TablaHash<>();
    TablaHash<Integer, Marca>       hashMarcas      = new TablaHash<>();
    TablaHash<Integer, TipoCliente> hashTipoCliente = new TablaHash<>();
    Grafo grafo = new Grafo();
    ConexionOracle conexion;
    Connection conn;
    boolean cargado = false;

    // Componentes UI
    JTabbedPane tabbedPane;
    JLabel lblEstado;
    PanelGrafo panelGrafo;
    JTable tablaHash, tablaFacturas, tablaDetalles;
    DefaultTableModel modelHash, modelFacturas, modelDetalles;
    JComboBox<String> cbClientes;
    JTextArea txtRelacion;

    public VentanaPrincipal() {
        setTitle("Sistema de Gestión Comercial — UMG | Programación III");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1200, 750);
        setLocationRelativeTo(null);
        setBackground(GRIS_FONDO);
        initUI();
    }

    private void initUI() {
        // Header
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(AZUL_UMG);
        header.setBorder(new EmptyBorder(12, 20, 12, 20));
        JLabel titulo = new JLabel("SISTEMA DE GESTIÓN COMERCIAL — UMG");
        titulo.setForeground(BLANCO);
        titulo.setFont(new Font("Segoe UI", Font.BOLD, 18));
        JLabel subtitulo = new JLabel("Programación III | Tablas Hash + Grafos | Sección B 2026");
        subtitulo.setForeground(new Color(180, 210, 255));
        subtitulo.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        JPanel titulos = new JPanel(new GridLayout(2,1));
        titulos.setOpaque(false);
        titulos.add(titulo);
        titulos.add(subtitulo);
        header.add(titulos, BorderLayout.WEST);

        JButton btnConectar = crearBoton("Conectar a Oracle", VERDE);
        btnConectar.addActionListener(e -> mostrarDialogoConexion());
        JButton btnCargar = crearBoton("Cargar Datos", AZUL_CLARO);
        btnCargar.addActionListener(e -> cargarDatos());
        JPanel botones = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        botones.setOpaque(false);
        botones.add(btnConectar);
        botones.add(btnCargar);
        header.add(botones, BorderLayout.EAST);

        // Status bar
        JPanel statusBar = new JPanel(new BorderLayout());
        statusBar.setBackground(new Color(230, 230, 240));
        statusBar.setBorder(new EmptyBorder(4, 16, 4, 16));
        lblEstado = new JLabel("⚪ Sin conexión — Haga clic en 'Conectar a Oracle'");
        lblEstado.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        statusBar.add(lblEstado, BorderLayout.WEST);

        // Tabs
        tabbedPane = new JTabbedPane();
        tabbedPane.setFont(new Font("Segoe UI", Font.BOLD, 13));
        tabbedPane.setBackground(GRIS_FONDO);
        tabbedPane.addTab("🔷 Tabla Hash", crearPanelHash());
        tabbedPane.addTab("🔶 Grafo Visual", crearPanelGrafo());
        tabbedPane.addTab("📄 Facturas y Detalles", crearPanelFacturas());
        tabbedPane.addTab("📊 Reportes", crearPanelReportes());

        setLayout(new BorderLayout());
        add(header, BorderLayout.NORTH);
        add(tabbedPane, BorderLayout.CENTER);
        add(statusBar, BorderLayout.SOUTH);
    }

    // ===================== PANEL HASH =====================
    private JPanel crearPanelHash() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBackground(GRIS_FONDO);
        panel.setBorder(new EmptyBorder(15, 15, 15, 15));

        // Selector de catalogo
        JPanel top = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 5));
        top.setBackground(GRIS_FONDO);
        top.add(new JLabel("Catálogo:"));
        JComboBox<String> cbCatalogo = new JComboBox<>(new String[]{"Productos", "Marcas", "Tipo Cliente"});
        cbCatalogo.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        top.add(cbCatalogo);
        JButton btnMostrar = crearBoton("Mostrar en Hash", AZUL_CLARO);
        top.add(btnMostrar);
        JLabel lblInfo = new JLabel("");
        lblInfo.setFont(new Font("Segoe UI", Font.ITALIC, 12));
        lblInfo.setForeground(AZUL_UMG);
        top.add(lblInfo);
        panel.add(top, BorderLayout.NORTH);

        // Tabla hash
        String[] cols = {"Posición Hash", "Clave", "Valor", "Colisión", "Tiempo Búsqueda (ns)"};
        modelHash = new DefaultTableModel(cols, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };
        tablaHash = new JTable(modelHash);
        estilizarTabla(tablaHash);
        panel.add(new JScrollPane(tablaHash), BorderLayout.CENTER);

        // Busqueda
        JPanel busq = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 5));
        busq.setBackground(GRIS_FONDO);
        busq.add(new JLabel("Buscar por ID:"));
        JTextField txtBuscar = new JTextField(8);
        busq.add(txtBuscar);
        JButton btnBuscar = crearBoton("Buscar", VERDE);
        JLabel lblResultado = new JLabel("");
        lblResultado.setFont(new Font("Segoe UI", Font.BOLD, 12));
        busq.add(btnBuscar);
        busq.add(lblResultado);
        panel.add(busq, BorderLayout.SOUTH);

        btnMostrar.addActionListener(e -> {
            if (!cargado) { mostrarAlerta("Primero cargue los datos."); return; }
            modelHash.setRowCount(0);
            int sel = cbCatalogo.getSelectedIndex();
            if (sel == 0) mostrarHashProductos(lblInfo);
            else if (sel == 1) mostrarHashMarcas(lblInfo);
            else mostrarHashTipos(lblInfo);
        });

        btnBuscar.addActionListener(e -> {
            if (!cargado) { mostrarAlerta("Primero cargue los datos."); return; }
            try {
                int id = Integer.parseInt(txtBuscar.getText().trim());
                int sel = cbCatalogo.getSelectedIndex();
                String resultado = "";
                long t1 = System.nanoTime();
                if (sel == 0) {
                    Producto p = hashProductos.buscar(id);
                    resultado = p != null ? "✅ " + p.getNombre() + " | Q" + p.getPrecio() : "❌ No encontrado";
                } else if (sel == 1) {
                    Marca m = hashMarcas.buscar(id);
                    resultado = m != null ? "✅ " + m.getNombre() + " (" + m.getPaisOrigen() + ")" : "❌ No encontrado";
                } else {
                    TipoCliente tc = hashTipoCliente.buscar(id);
                    resultado = tc != null ? "✅ " + tc.getNombre() : "❌ No encontrado";
                }
                long tiempo = System.nanoTime() - t1;
                lblResultado.setText(resultado + " | " + tiempo + " ns");
                lblResultado.setForeground(resultado.startsWith("✅") ? VERDE : Color.RED);
            } catch (NumberFormatException ex) {
                mostrarAlerta("Ingrese un ID numérico.");
            }
        });

        return panel;
    }

    private void mostrarHashProductos(JLabel lbl) {
        NodoHash<Integer, Producto>[] arr = hashProductos.getTabla();
        int col = 0;
        for (int i = 0; i < arr.length; i++) {
            NodoHash<Integer, Producto> n = arr[i];
            boolean primero = true;
            while (n != null) {
                long t = System.nanoTime(); hashProductos.buscar(n.getClave()); long t2 = System.nanoTime()-t;
                modelHash.addRow(new Object[]{i, n.getClave(), n.getValor().getNombre(), primero ? "" : "⚠ COLISIÓN", t2});
                primero = false; if (!primero) col++;
                n = n.getSiguiente();
            }
        }
        lbl.setText("Productos: " + modelHash.getRowCount() + " | Colisiones: " + hashProductos.getColisiones());
    }

    private void mostrarHashMarcas(JLabel lbl) {
        NodoHash<Integer, Marca>[] arr = hashMarcas.getTabla();
        for (int i = 0; i < arr.length; i++) {
            NodoHash<Integer, Marca> n = arr[i];
            boolean primero = true;
            while (n != null) {
                long t = System.nanoTime(); hashMarcas.buscar(n.getClave()); long t2 = System.nanoTime()-t;
                modelHash.addRow(new Object[]{i, n.getClave(), n.getValor().getNombre()+" ("+n.getValor().getPaisOrigen()+")", primero ? "" : "⚠ COLISIÓN", t2});
                primero = false; n = n.getSiguiente();
            }
        }
        lbl.setText("Marcas: " + modelHash.getRowCount() + " | Colisiones: " + hashMarcas.getColisiones());
    }

    private void mostrarHashTipos(JLabel lbl) {
        NodoHash<Integer, TipoCliente>[] arr = hashTipoCliente.getTabla();
        for (int i = 0; i < arr.length; i++) {
            NodoHash<Integer, TipoCliente> n = arr[i];
            boolean primero = true;
            while (n != null) {
                long t = System.nanoTime(); hashTipoCliente.buscar(n.getClave()); long t2 = System.nanoTime()-t;
                modelHash.addRow(new Object[]{i, n.getClave(), n.getValor().getNombre(), primero ? "" : "⚠ COLISIÓN", t2});
                primero = false; n = n.getSiguiente();
            }
        }
        lbl.setText("TipoCliente: " + modelHash.getRowCount() + " | Colisiones: " + hashTipoCliente.getColisiones());
    }

    // ===================== PANEL GRAFO =====================
    private JPanel crearPanelGrafo() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBackground(GRIS_FONDO);
        panel.setBorder(new EmptyBorder(10, 10, 10, 10));

        JPanel top = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 5));
        top.setBackground(GRIS_FONDO);
        top.add(new JLabel("Cliente ID:"));
        cbClientes = new JComboBox<>();
        cbClientes.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        cbClientes.setPreferredSize(new Dimension(200, 28));
        top.add(cbClientes);
        JButton btnVerGrafo = crearBoton("Ver Grafo", NARANJA);
        top.add(btnVerGrafo);

        // Leyenda
        JPanel leyenda = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 5));
        leyenda.setBackground(GRIS_FONDO);
        agregarLeyenda(leyenda, "CLIENTE", new Color(0, 102, 204));
        agregarLeyenda(leyenda, "FACTURA", new Color(153, 0, 153));
        agregarLeyenda(leyenda, "DETALLE", new Color(204, 102, 0));
        agregarLeyenda(leyenda, "PRODUCTO", new Color(0, 153, 76));
        agregarLeyenda(leyenda, "MARCA", new Color(204, 0, 0));

        JPanel topBar = new JPanel(new BorderLayout());
        topBar.setBackground(GRIS_FONDO);
        topBar.add(top, BorderLayout.WEST);
        topBar.add(leyenda, BorderLayout.EAST);

        panelGrafo = new PanelGrafo();
        JScrollPane scroll = new JScrollPane(panelGrafo);
        scroll.setPreferredSize(new Dimension(900, 500));

        txtRelacion = new JTextArea(6, 40);
        txtRelacion.setFont(new Font("Consolas", Font.PLAIN, 11));
        txtRelacion.setEditable(false);
        txtRelacion.setBackground(new Color(30, 30, 30));
        txtRelacion.setForeground(new Color(0, 255, 128));
        JScrollPane scrollTxt = new JScrollPane(txtRelacion);

        JSplitPane split = new JSplitPane(JSplitPane.VERTICAL_SPLIT, scroll, scrollTxt);
        split.setDividerLocation(480);

        panel.add(topBar, BorderLayout.NORTH);
        panel.add(split, BorderLayout.CENTER);

        btnVerGrafo.addActionListener(e -> {
            if (!cargado) { mostrarAlerta("Primero cargue los datos."); return; }
            String sel = (String) cbClientes.getSelectedItem();
            if (sel == null) return;
            int idCliente = Integer.parseInt(sel.split(" - ")[0].trim());
            panelGrafo.cargarGrafo(grafo, idCliente);
            txtRelacion.setText(grafo.relacionCompleta(idCliente));
        });

        return panel;
    }

    private void agregarLeyenda(JPanel panel, String texto, Color color) {
        JPanel item = new JPanel(new FlowLayout(FlowLayout.LEFT, 4, 0));
        item.setBackground(panel.getBackground());
        JLabel cuadro = new JLabel("  ");
        cuadro.setOpaque(true);
        cuadro.setBackground(color);
        cuadro.setPreferredSize(new Dimension(14, 14));
        item.add(cuadro);
        JLabel lbl = new JLabel(texto);
        lbl.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        item.add(lbl);
        panel.add(item);
    }

    // ===================== PANEL FACTURAS =====================
    private JPanel crearPanelFacturas() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBackground(GRIS_FONDO);
        panel.setBorder(new EmptyBorder(15, 15, 15, 15));

        JPanel top = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 5));
        top.setBackground(GRIS_FONDO);
        top.add(new JLabel("Cliente:"));
        JComboBox<String> cbCli = new JComboBox<>();
        cbCli.setPreferredSize(new Dimension(220, 28));
        top.add(cbCli);
        JButton btnVer = crearBoton("Ver Facturas", AZUL_CLARO);
        top.add(btnVer);

        String[] colsFac = {"ID Factura", "Cliente", "Fecha", "Total (Q)", "Año", "Tipo Cliente"};
        modelFacturas = new DefaultTableModel(colsFac, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };
        tablaFacturas = new JTable(modelFacturas);
        estilizarTabla(tablaFacturas);

        String[] colsDet = {"ID Detalle", "ID Factura", "Producto", "Marca (Hash)", "Cantidad", "Precio Unit.", "Subtotal"};
        modelDetalles = new DefaultTableModel(colsDet, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };
        tablaDetalles = new JTable(modelDetalles);
        estilizarTabla(tablaDetalles);

        JSplitPane split = new JSplitPane(JSplitPane.VERTICAL_SPLIT,
            new JScrollPane(tablaFacturas), new JScrollPane(tablaDetalles));
        split.setDividerLocation(250);

        JLabel lblTitDet = new JLabel("  Detalles de la factura seleccionada:");
        lblTitDet.setFont(new Font("Segoe UI", Font.BOLD, 12));
        lblTitDet.setForeground(AZUL_UMG);

        panel.add(top, BorderLayout.NORTH);
        panel.add(split, BorderLayout.CENTER);
        panel.add(lblTitDet, BorderLayout.SOUTH);

        btnVer.addActionListener(e -> {
            if (!cargado) { mostrarAlerta("Primero cargue los datos."); return; }
            String sel = (String) cbCli.getSelectedItem();
            if (sel == null) return;
            int idCli = Integer.parseInt(sel.split(" - ")[0].trim());
            cargarFacturasCliente(idCli);
        });

        tablaFacturas.getSelectionModel().addListSelectionListener(ev -> {
            int row = tablaFacturas.getSelectedRow();
            if (row >= 0) {
                int idFac = (int) modelFacturas.getValueAt(row, 0);
                cargarDetallesFactura(idFac);
            }
        });

        // Sincronizar combo con el de grafos cuando se carguen datos
        tabbedPane.addChangeListener(ce -> {
            if (tabbedPane.getSelectedIndex() == 2 && cargado && cbCli.getItemCount() == 0) {
                for (int i = 0; i < cbClientes.getItemCount(); i++) {
                    cbCli.addItem(cbClientes.getItemAt(i));
                }
            }
        });

        return panel;
    }

    private void cargarFacturasCliente(int idCliente) {
        modelFacturas.setRowCount(0);
        modelDetalles.setRowCount(0);
        try {
            String sql = "SELECT F.ID_FACTURA, C.NOMBRE||' '||C.APELLIDO AS CLIENTE, F.FECHA, F.TOTAL, F.ANIO, TC.NOMBRE AS TIPO " +
                         "FROM FACTURA F JOIN CLIENTE C ON F.ID_CLIENTE=C.ID_CLIENTE " +
                         "JOIN TIPO_CLIENTE TC ON C.ID_TIPO_CLIENTE=TC.ID_TIPO_CLIENTE " +
                         "WHERE F.ID_CLIENTE=? ORDER BY F.ANIO, F.FECHA";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, idCliente);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                TipoCliente tc = hashTipoCliente.buscar(rs.getInt("ANIO") > 0 ? 1 : 1);
                modelFacturas.addRow(new Object[]{
                    rs.getInt("ID_FACTURA"), rs.getString("CLIENTE"),
                    rs.getDate("FECHA"), rs.getDouble("TOTAL"),
                    rs.getInt("ANIO"), rs.getString("TIPO") + " (TH)"
                });
            }
        } catch (SQLException ex) {
            mostrarAlerta("Error al cargar facturas: " + ex.getMessage());
        }
    }

    private void cargarDetallesFactura(int idFactura) {
        modelDetalles.setRowCount(0);
        try {
            String sql = "SELECT D.ID_DETALLE, D.ID_FACTURA, P.NOMBRE AS PRODUCTO, M.NOMBRE AS MARCA, " +
                         "D.CANTIDAD, D.PRECIO_UNITARIO, D.SUBTOTAL " +
                         "FROM DETALLE D JOIN PRODUCTO P ON D.ID_PRODUCTO=P.ID_PRODUCTO " +
                         "JOIN MARCA M ON P.ID_MARCA=M.ID_MARCA WHERE D.ID_FACTURA=?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, idFactura);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                int idMarca = 0;
                // Buscar marca via hash
                Producto p = hashProductos.buscar(rs.getInt("ID_DETALLE"));
                modelDetalles.addRow(new Object[]{
                    rs.getInt("ID_DETALLE"), rs.getInt("ID_FACTURA"),
                    rs.getString("PRODUCTO"), rs.getString("MARCA") + " (TH)",
                    rs.getInt("CANTIDAD"), "Q" + rs.getDouble("PRECIO_UNITARIO"),
                    "Q" + rs.getDouble("SUBTOTAL")
                });
            }
        } catch (SQLException ex) {
            mostrarAlerta("Error al cargar detalles: " + ex.getMessage());
        }
    }

    // ===================== PANEL REPORTES =====================
    private JPanel crearPanelReportes() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(GRIS_FONDO);
        panel.setBorder(new EmptyBorder(30, 40, 30, 40));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(12, 12, 12, 12);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel titulo = new JLabel("Generación de Reportes (.docx)");
        titulo.setFont(new Font("Segoe UI", Font.BOLD, 16));
        titulo.setForeground(AZUL_UMG);
        gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 2;
        panel.add(titulo, gbc);

        gbc.gridwidth = 1;

        // Reporte 4.1
        gbc.gridx=0; gbc.gridy=1;
        panel.add(crearTarjetaReporte(
            "Reporte 4.1", "Productos en Tabla Hash",
            "Lista de productos con clave hash, posición y tiempo de búsqueda.",
            AZUL_CLARO, e -> {
                if (!cargado) { mostrarAlerta("Primero cargue los datos."); return; }
                new GeneradorReporte().generarReporteProductosHash(hashProductos);
                JOptionPane.showMessageDialog(this, "✅ reporte_productos_hash.docx generado en la carpeta del proyecto.");
            }), gbc);

        // Reporte 4.2
        gbc.gridx=1; gbc.gridy=1;
        panel.add(crearTarjetaReporte(
            "Reporte 4.2", "Productos y su Marca",
            "Relación Producto-Marca con tiempo de búsqueda en tabla hash.",
            VERDE, e -> {
                if (!cargado) { mostrarAlerta("Primero cargue los datos."); return; }
                new GeneradorReporte().generarReporteProductosMarca(hashProductos, hashMarcas);
                JOptionPane.showMessageDialog(this, "✅ reporte_productos_marca.docx generado.");
            }), gbc);

        // Reporte 4.3
        gbc.gridx=0; gbc.gridy=2; gbc.gridwidth=2;
        JPanel panelR3 = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 5));
        panelR3.setBackground(GRIS_FONDO);
        panelR3.add(new JLabel("ID Cliente para Reporte 4.3:"));
        JTextField txtIdCli = new JTextField(6);
        panelR3.add(txtIdCli);
        JButton btnR3 = crearBoton("Generar Reporte 4.3 — Grafo Cliente", NARANJA);
        panelR3.add(btnR3);
        panel.add(panelR3, gbc);

        btnR3.addActionListener(e -> {
            if (!cargado) { mostrarAlerta("Primero cargue los datos."); return; }
            try {
                int id = Integer.parseInt(txtIdCli.getText().trim());
                new GeneradorReporte().generarReporteGrafoCliente(grafo, id, new int[]{2024, 2025, 2026});
                JOptionPane.showMessageDialog(this, "✅ reporte_grafo_cliente_" + id + ".docx generado.");
            } catch (NumberFormatException ex) {
                mostrarAlerta("Ingrese un ID de cliente válido.");
            }
        });

        return panel;
    }

    private JPanel crearTarjetaReporte(String titulo, String subtitulo, String desc, Color color, ActionListener al) {
        JPanel card = new JPanel(new BorderLayout(8,8));
        card.setBackground(BLANCO);
        card.setBorder(BorderFactory.createCompoundBorder(
            new LineBorder(color, 2, true),
            new EmptyBorder(16, 16, 16, 16)
        ));
        card.setPreferredSize(new Dimension(340, 160));
        JLabel lTitulo = new JLabel(titulo);
        lTitulo.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lTitulo.setForeground(color);
        JLabel lSub = new JLabel(subtitulo);
        lSub.setFont(new Font("Segoe UI", Font.BOLD, 12));
        JLabel lDesc = new JLabel("<html><body style='width:280px'>" + desc + "</body></html>");
        lDesc.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        JButton btn = crearBoton("Generar", color);
        btn.addActionListener(al);
        JPanel texto = new JPanel(new GridLayout(3,1,4,4));
        texto.setOpaque(false);
        texto.add(lTitulo); texto.add(lSub); texto.add(lDesc);
        card.add(texto, BorderLayout.CENTER);
        card.add(btn, BorderLayout.SOUTH);
        return card;
    }

    // ===================== CONEXION =====================
    private void mostrarDialogoConexion() {
        JDialog dlg = new JDialog(this, "Conexión a Oracle", true);
        dlg.setSize(380, 300);
        dlg.setLocationRelativeTo(this);
        dlg.setLayout(new GridBagLayout());
        GridBagConstraints g = new GridBagConstraints();
        g.insets = new Insets(8,10,8,10);
        g.fill = GridBagConstraints.HORIZONTAL;

        JTextField tHost = new JTextField("localhost", 15);
        JTextField tPort = new JTextField("1521", 15);
        JTextField tSid  = new JTextField("XE", 15);
        JTextField tUser = new JTextField("system", 15);
        JPasswordField tPass = new JPasswordField(15);

        String[][] campos = {{"Host:", null}, {"Puerto:", null}, {"SID:", null}, {"Usuario:", null}, {"Contraseña:", null}};
        JTextField[] fields = {tHost, tPort, tSid, tUser, tPass};
        String[] labels = {"Host:", "Puerto:", "SID:", "Usuario:", "Contraseña:"};
        for (int i = 0; i < labels.length; i++) {
            g.gridx=0; g.gridy=i; g.weightx=0.3;
            dlg.add(new JLabel(labels[i]), g);
            g.gridx=1; g.weightx=0.7;
            dlg.add(fields[i], g);
        }

        JButton btnOk = crearBoton("Conectar", VERDE);
        g.gridx=0; g.gridy=5; g.gridwidth=2;
        dlg.add(btnOk, g);

        btnOk.addActionListener(e -> {
            try {
                conexion = new ConexionOracle(tHost.getText(), tPort.getText(), tSid.getText(),
                    tUser.getText(), new String(tPass.getPassword()));
                conn = conexion.getConexion();
                lblEstado.setText("🟢 Conectado a Oracle " + tHost.getText() + ":" + tPort.getText() + "/" + tSid.getText());
                lblEstado.setForeground(VERDE);
                dlg.dispose();
                JOptionPane.showMessageDialog(this, "✅ Conexión exitosa. Ahora haga clic en 'Cargar Datos'.");
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(dlg, "❌ Error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        });
        dlg.setVisible(true);
    }

    private void cargarDatos() {
        if (conn == null) { mostrarAlerta("Primero conéctese a Oracle."); return; }
        SwingWorker<Void, String> worker = new SwingWorker<>() {
            protected Void doInBackground() throws Exception {
                publish("⏳ Cargando catálogos en Tablas Hash...");
                hashProductos = new TablaHash<>();
                hashMarcas = new TablaHash<>();
                hashTipoCliente = new TablaHash<>();
                conexion.cargarHashDesdeBD(hashProductos, hashMarcas, hashTipoCliente);
                publish("⏳ Cargando Grafo desde Oracle...");
                grafo = new Grafo();
                grafo.cargarDesdeOracle(conn);
                publish("⏳ Cargando lista de clientes...");
                cargarComboClientes();
                return null;
            }
            protected void process(List<String> chunks) {
                lblEstado.setText(chunks.get(chunks.size()-1));
            }
            protected void done() {
                try { get(); cargado = true;
                    lblEstado.setText("🟢 Datos cargados — Productos: " + hashProductos.getColisiones() +
                        " col. | Marcas: " + hashMarcas.getColisiones() + " col.");
                    lblEstado.setForeground(VERDE);
                } catch (Exception ex) {
                    lblEstado.setText("❌ Error: " + ex.getMessage());
                    lblEstado.setForeground(Color.RED);
                }
            }
        };
        worker.execute();
    }

    private void cargarComboClientes() throws SQLException {
        cbClientes.removeAllItems();
        String sql = "SELECT ID_CLIENTE, NOMBRE||' '||APELLIDO AS NOM FROM CLIENTE ORDER BY ID_CLIENTE";
        PreparedStatement ps = conn.prepareStatement(sql);
        ResultSet rs = ps.executeQuery();
        while (rs.next()) {
            cbClientes.addItem(rs.getInt("ID_CLIENTE") + " - " + rs.getString("NOM"));
        }
    }

    // ===================== UTILIDADES =====================
    private JButton crearBoton(String texto, Color color) {
        JButton btn = new JButton(texto);
        btn.setBackground(color);
        btn.setForeground(BLANCO);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btn.setBorder(new EmptyBorder(8, 16, 8, 16));
        btn.setFocusPainted(false);
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btn.setOpaque(true);
        return btn;
    }

    private void estilizarTabla(JTable tabla) {
        tabla.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        tabla.setRowHeight(26);
        tabla.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 12));
        tabla.getTableHeader().setBackground(AZUL_UMG);
        tabla.getTableHeader().setForeground(BLANCO);
        tabla.setSelectionBackground(new Color(200, 220, 255));
        tabla.setGridColor(new Color(210, 210, 220));
        tabla.setShowGrid(true);
        tabla.setIntercellSpacing(new Dimension(1,1));
    }

    private void mostrarAlerta(String msg) {
        JOptionPane.showMessageDialog(this, msg, "Aviso", JOptionPane.WARNING_MESSAGE);
    }

    public static void main(String[] args) {
        try { UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName()); } catch (Exception e) {}
        SwingUtilities.invokeLater(() -> new VentanaPrincipal().setVisible(true));
    }
}

// ===================== PANEL GRAFO VISUAL =====================
class PanelGrafo extends JPanel {

    private List<NodoVisual> nodos = new ArrayList<>();
    private List<AristaVisual> aristas = new ArrayList<>();

    static final Color C_CLIENTE  = new Color(0, 102, 204);
    static final Color C_FACTURA  = new Color(153, 0, 153);
    static final Color C_DETALLE  = new Color(204, 102, 0);
    static final Color C_PRODUCTO = new Color(0, 153, 76);
    static final Color C_MARCA    = new Color(204, 0, 0);

    public PanelGrafo() {
        setBackground(new Color(20, 20, 35));
        setPreferredSize(new Dimension(1100, 600));
    }

    public void cargarGrafo(Grafo grafo, int idCliente) {
        nodos.clear(); aristas.clear();
        NodoGrafo cliente = grafo.getNodo(idCliente);
        if (cliente == null) { repaint(); return; }

        Map<Integer, Point> posiciones = new HashMap<>();
        int anchoPanel = Math.max(getWidth(), 1100);

        // CLIENTE centro-izquierda
        int cx = 100, cy = 300;
        agregarNodo(cliente, cx, cy, posiciones);

        // FACTURAS en columna
        List<NodoGrafo> facturas = new ArrayList<>();
        for (AristaGrafo a : cliente.getAdyacentes()) {
            if ("FACTURA".equals(a.getDestino().getTipo())) facturas.add(a.getDestino());
        }
        int facY = Math.max(50, 300 - (facturas.size() * 80) / 2);
        for (NodoGrafo fac : facturas) {
            agregarNodo(fac, 280, facY, posiciones);
            agregarArista(cliente.getId(), fac.getId(), "tiene");
            facY += 80;

            // DETALLES
            int detY = posiciones.get(fac.getId()).y - 30;
            for (AristaGrafo ad : fac.getAdyacentes()) {
                NodoGrafo det = ad.getDestino();
                if (!"DETALLE".equals(det.getTipo())) continue;
                agregarNodo(det, 480, detY, posiciones);
                agregarArista(fac.getId(), det.getId(), "");
                detY += 55;

                // PRODUCTO
                for (AristaGrafo ap : det.getAdyacentes()) {
                    NodoGrafo prod = ap.getDestino();
                    if (!"PRODUCTO".equals(prod.getTipo())) continue;
                    if (!posiciones.containsKey(prod.getId())) {
                        agregarNodo(prod, 680, detY - 28, posiciones);
                    }
                    agregarArista(det.getId(), prod.getId(), "");

                    // MARCA
                    for (AristaGrafo am : prod.getAdyacentes()) {
                        NodoGrafo marca = am.getDestino();
                        if (!"MARCA".equals(marca.getTipo())) continue;
                        if (!posiciones.containsKey(marca.getId())) {
                            agregarNodo(marca, 880, posiciones.get(prod.getId()).y, posiciones);
                        }
                        agregarArista(prod.getId(), marca.getId(), "(TH)");
                    }
                }
            }
        }
        repaint();
    }

    private void agregarNodo(NodoGrafo n, int x, int y, Map<Integer,Point> pos) {
        pos.put(n.getId(), new Point(x, y));
        nodos.add(new NodoVisual(n, x, y));
    }

    private void agregarArista(int desde, int hasta, String etiqueta) {
        aristas.add(new AristaVisual(desde, hasta, etiqueta));
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        Map<Integer, Point> posMap = new HashMap<>();
        for (NodoVisual n : nodos) posMap.put(n.nodo.getId(), new Point(n.x, n.y));

        // Dibujar aristas
        g2.setStroke(new BasicStroke(1.8f));
        for (AristaVisual a : aristas) {
            Point p1 = posMap.get(a.desde);
            Point p2 = posMap.get(a.hasta);
            if (p1 == null || p2 == null) continue;
            g2.setColor(new Color(150, 150, 180));
            g2.drawLine(p1.x + 60, p1.y + 15, p2.x, p2.y + 15);
            // Flecha
            dibujarFlecha(g2, p1.x+60, p1.y+15, p2.x, p2.y+15);
            if (!a.etiqueta.isEmpty()) {
                g2.setColor(new Color(200, 200, 100));
                g2.setFont(new Font("Segoe UI", Font.PLAIN, 9));
                g2.drawString(a.etiqueta, (p1.x+60+p2.x)/2, (p1.y+p2.y)/2 + 10);
            }
        }

        // Dibujar nodos
        for (NodoVisual n : nodos) {
            Color color = colorPorTipo(n.nodo.getTipo());
            g2.setColor(color);
            g2.fillRoundRect(n.x, n.y, 120, 30, 10, 10);
            g2.setColor(color.brighter());
            g2.setStroke(new BasicStroke(1.5f));
            g2.drawRoundRect(n.x, n.y, 120, 30, 10, 10);
            g2.setColor(Color.WHITE);
            g2.setFont(new Font("Segoe UI", Font.BOLD, 10));
            String tipo = "[" + n.nodo.getTipo().charAt(0) + "] ";
            String etiq = n.nodo.getEtiqueta();
            if (etiq.length() > 14) etiq = etiq.substring(0, 13) + "…";
            g2.drawString(tipo + etiq, n.x + 5, n.y + 19);
        }
    }

    private void dibujarFlecha(Graphics2D g2, int x1, int y1, int x2, int y2) {
        double ang = Math.atan2(y2 - y1, x2 - x1);
        int len = 8;
        int[] xp = {x2, (int)(x2 - len*Math.cos(ang-0.4)), (int)(x2 - len*Math.cos(ang+0.4))};
        int[] yp = {y2, (int)(y2 - len*Math.sin(ang-0.4)), (int)(y2 - len*Math.sin(ang+0.4))};
        g2.fillPolygon(xp, yp, 3);
    }

    private Color colorPorTipo(String tipo) {
        switch (tipo) {
            case "CLIENTE":  return C_CLIENTE;
            case "FACTURA":  return C_FACTURA;
            case "DETALLE":  return C_DETALLE;
            case "PRODUCTO": return C_PRODUCTO;
            case "MARCA":    return C_MARCA;
            default: return Color.GRAY;
        }
    }

    static class NodoVisual {
        NodoGrafo nodo; int x, y;
        NodoVisual(NodoGrafo n, int x, int y) { this.nodo=n; this.x=x; this.y=y; }
    }
    static class AristaVisual {
        int desde, hasta; String etiqueta;
        AristaVisual(int d, int h, String e) { desde=d; hasta=h; etiqueta=e; }
    }
}
